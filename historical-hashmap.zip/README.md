# Simple hashcode with travel machine

# How to execute

```bash
npm install
npm run build
npm run sample
````
